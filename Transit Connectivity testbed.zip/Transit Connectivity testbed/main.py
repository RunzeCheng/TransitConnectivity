"""
Main application entry point for the Enhanced OSM Connectivity Scenario Simulator
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import random
from typing import Dict, List, Optional

from models import OSMNode, OSMWay, VehiclePath
from osm_parser import OSMParser
from simulation_logic import SimulationEngine
from visualization import CanvasRenderer
from metrics_logger import MetricsLogger


class EnhancedScenarioSimulator(tk.Tk):
    """Main application window and controller"""
    
    def __init__(self):
        super().__init__()
        self.title("Enhanced OSM Connectivity Scenario Simulator")
        self.geometry("1600x1000")
        self.resizable(True, True)
        
        # OSM data
        self.osm_nodes: Dict[str, OSMNode] = {}
        self.osm_ways: Dict[str, OSMWay] = {}
        self.road_ways: List[OSMWay] = []
        self.vehicle_paths: List[VehiclePath] = []
        
        # Map bounds
        self.min_lat = self.max_lat = self.min_lon = self.max_lon = None
        self.map_loaded = False
        
        # Simulation parameters
        self.road_vehicle_count = tk.IntVar(value=50)
        self.train_carriages = tk.IntVar(value=0)
        self.base_stations = tk.IntVar(value=6)
        self.satellites = tk.IntVar(value=0)
        
        # Simulation objects
        self.road_vehicles_list = []
        self.train_carriages_list = []
        self.bs_list = []
        self.sat_list = []
        
        # Vehicle speed
        self.vehicle_speed = 0.005
        
        # SemCom configuration
        self.semcom_enabled_var = tk.BooleanVar(value=False)
        self.semcom_compression_ratio = tk.DoubleVar(value=0.5)
        self.semcom_config = {
            "bandwidth_mb_s": 12.5,
            "base_delay_s": 0.001,
            "compute_capacity_mb_s": 1000000/16,
            "alpha": 1.0
        }
        
        # Digital Twin configuration
        self.dt_type_var = tk.StringVar(value="traditional")
        self.dt_config = {
            "type": "traditional",
            "cloud_delay_ms": 50.0
        }
        
        # Simulation state
        self.tick = 0
        self.simulation_running = False
        
        # Components
        self.renderer = None
        self.engine = None
        self.logger = MetricsLogger(testnum=0)
        
        # Create UI
        self.create_widgets()

    def start_pan(self, event):
        """Start panning operation"""
        self._pan_last_x = event.x
        self._pan_last_y = event.y

    def pan_move(self, event):
        """Handle panning movement"""
        if not hasattr(self, '_pan_last_x'):
            return
            
        dx = event.x - self._pan_last_x
        dy = event.y - self._pan_last_y

        # Update offsets
        self.renderer.offset_x += dx
        self.renderer.offset_y += dy

        # Remember last positions
        self._pan_last_x = event.x
        self._pan_last_y = event.y

        # Redraw with new offsets
        self.redraw_canvas()

    def end_pan(self, event):
        """End panning operation"""
        pass  # Optional, placeholder if you want momentum later
    
    def zoom_in(self, event):
        """Zoom in at mouse position"""
        if self.renderer is None:
            return
        self.renderer.zoom_in(event.x, event.y)
        self.redraw_canvas()
    
    def zoom_out(self, event):
        """Zoom out at mouse position"""
        if self.renderer is None:
            return
        self.renderer.zoom_out(event.x, event.y)
        self.redraw_canvas()
    
    def on_mousewheel(self, event):
        """Handle mouse wheel zoom"""
        if self.renderer is None:
            return
        
        # Get mouse position relative to canvas
        # event.x and event.y are already relative to the canvas widget
        x = event.x
        y = event.y
        
        # Windows uses delta, Linux uses num
        # On Windows, delta is typically 120 or -120
        # On Linux, num is 4 (scroll up) or 5 (scroll down)
        if event.num == 4 or (hasattr(event, 'delta') and event.delta > 0):
            self.renderer.zoom_in(x, y)
        elif event.num == 5 or (hasattr(event, 'delta') and event.delta < 0):
            self.renderer.zoom_out(x, y)
        self.redraw_canvas()


    def create_widgets(self):
        """Create all UI widgets"""
        # Import the UI creation from a separate module would be ideal
        # For now, keeping minimal structure here
        from ui_components import UIBuilder
        ui_builder = UIBuilder(self)
        ui_builder.create_all_widgets()
    
    def load_osm_file(self):
        """Load an OSM XML file"""
        file_path = filedialog.askopenfilename(
            title="Select OSM File",
            filetypes=[("OSM files", "*.osm"), ("XML files", "*.xml"), ("All files", "*.*")]
        )
        
        if file_path:
            try:
                self.osm_nodes, self.osm_ways, self.road_ways = OSMParser.parse_osm_file(file_path)
                self.min_lat, self.max_lat, self.min_lon, self.max_lon = OSMParser.get_bounds(self.osm_nodes)
                
                OSMParser.convert_coordinates_to_canvas(
                    self.osm_nodes, self.min_lat, self.max_lat, 
                    self.min_lon, self.max_lon
                )
                
                self.vehicle_paths = OSMParser.create_vehicle_paths(self.road_ways, self.osm_nodes)
                
                self.osm_status.set(f"Loaded: {len(self.road_ways)} roads from OSM file")
                self.map_loaded = True
                self.redraw_canvas()
                self.center_map()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load OSM file: {str(e)}")
    
    def load_sample_osm(self):
        """Create sample OSM data for testing"""
        self.osm_nodes, self.osm_ways, self.road_ways = OSMParser.create_sample_data()
        self.min_lat, self.max_lat, self.min_lon, self.max_lon = OSMParser.get_bounds(self.osm_nodes)
        
        OSMParser.convert_coordinates_to_canvas(
            self.osm_nodes, self.min_lat, self.max_lat,
            self.min_lon, self.max_lon
        )
        
        self.vehicle_paths = OSMParser.create_vehicle_paths(self.road_ways, self.osm_nodes)
        
        self.osm_status.set(f"Loaded sample data: {len(self.road_ways)} roads")
        self.map_loaded = True
        self.redraw_canvas()
        self.center_map()
    
    def simulate_scenario(self):
        """Start the simulation"""
        if not self.map_loaded:
            messagebox.showwarning("Warning", "Please load an OSM file first!")
            return
        
        if not self.vehicle_paths:
            messagebox.showwarning("Warning", "No road paths available for vehicles!")
            return
        
        # Update DT config
        self.dt_config["type"] = self.dt_type_var.get()
        
        # Initialize engine
        self.engine = SimulationEngine(self.semcom_config, self.dt_config)
        
        # Reset tick
        self.tick = 0
        
        # Initialize simulation objects
        self.initialize_simulation_objects()
        
        # Start simulation loop
        if not self.simulation_running:
            self.simulation_running = True
            self.start_button.config(state="disabled")
            self.stop_button.config(state="normal")
            self.update_simulation()
    
    def stop_simulation(self):
        """Stop the simulation"""
        self.simulation_running = False
        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")
        self.status_var.set("Simulation stopped")
    
    def initialize_simulation_objects(self):
        """Initialize all simulation objects"""
        # Clear previous objects
        self.road_vehicles_list = []
        self.train_carriages_list = []
        self.bs_list = []
        self.sat_list = []
        
        road_count = int(self.road_vehicle_count.get())
        rail_count = int(self.train_carriages.get())
        bs_count = int(self.base_stations.get())
        sat_count = int(self.satellites.get())
        
        semcom_enabled = self.semcom_enabled_var.get()
        compression_ratio = self.semcom_compression_ratio.get()
        
        # Create road vehicles
        for i in range(road_count):
            if not self.vehicle_paths:
                break
            
            path = random.choice(self.vehicle_paths)
            progress = random.uniform(0, 1)
            
            vehicle = self.engine.create_road_vehicle(
                f"V{i+1}", path, progress, semcom_enabled, compression_ratio
            )
            self.road_vehicles_list.append(vehicle)
        
        # Create train carriages
        if rail_count > 0:
            canvas_width = 1000
            track_y = 100
            spacing = canvas_width // (rail_count + 1)
            
            for i in range(rail_count):
                carriage = self.engine.create_train_carriage(
                    f"C{i+1}", spacing * (i + 1), track_y,
                    semcom_enabled, compression_ratio
                )
                self.train_carriages_list.append(carriage)
        
        # Create base stations and satellites
        self._create_access_points(bs_count, sat_count)
    
    def _create_access_points(self, bs_count: int, sat_count: int):
        """Create base stations and satellites"""
        if self.osm_nodes:
            xs = [node.x for node in self.osm_nodes.values()]
            ys = [node.y for node in self.osm_nodes.values()]
            min_x, max_x = min(xs), max(xs)
            min_y, max_y = min(ys), max(ys)
        else:
            min_x, max_x = 100, 900
            min_y, max_y = 100, 600
        
        for i in range(bs_count):
            bs = {
                "id": f"BS{i+1}",
                "type": "Base Station",
                "x": random.uniform(min_x + 50, max_x - 50),
                "y": random.uniform(min_y + 50, max_y - 50),
                "total_bw": 20,
                "available_bw": 20,
                "connected_users": []
            }
            self.bs_list.append(bs)
        
        center_x = (min_x + max_x) / 2 if max_x > min_x else 500
        for i in range(sat_count):
            sat = {
                "id": f"SAT{i+1}",
                "type": "Satellite",
                "x": center_x + (i * 50 - (sat_count-1) * 25),
                "y": min_y - 50,
                "total_bw": 500,
                "available_bw": 500,
                "connected_users": []
            }
            self.sat_list.append(sat)
    
    def update_simulation(self):
        """Update simulation state"""
        # Update vehicle positions and requirements
        self._update_vehicles()
        
        # Assign connections
        all_users = self.road_vehicles_list + self.train_carriages_list
        all_aps = self.bs_list + self.sat_list
        SimulationEngine.assign_connections(all_users, all_aps)
        
        # Calculate metrics and log
        metrics = SimulationEngine.calculate_metrics(all_users, all_aps)
        self.logger.log_metrics(
            self.tick, metrics,
            self.dt_type_var.get(),
            self.dt_config["cloud_delay_ms"],
            self.semcom_enabled_var.get(),
            self.semcom_compression_ratio.get()
        )
        
        # Update displays
        self.redraw_canvas()
        self.update_requirement_displays()
        
        # Update status
        self._update_status_bar(metrics)
        
        self.tick += 1
        
        # Schedule next update
        if self.simulation_running:
            self.after(1000, self.update_simulation)
    
    def _update_vehicles(self):
        """Update vehicle positions and occasionally change requirements"""
        for vehicle in self.road_vehicles_list:
            vehicle["progress"] += self.vehicle_speed
            
            if vehicle["progress"] >= 1.0:
                vehicle["progress"] = 0.0
                if random.random() < 0.1:
                    vehicle["path"] = random.choice(self.vehicle_paths)
            
            vehicle["x"], vehicle["y"] = vehicle["path"].get_position_at_progress(vehicle["progress"])
            vehicle["direction"] = vehicle["path"].get_direction_at_progress(vehicle["progress"])
            
            if random.random() < 0.02:
                self._update_user_requirements(vehicle)
        
        for carriage in self.train_carriages_list:
            carriage["x"] = carriage["x"] + random.randint(-2, 2)
            
            if random.random() < 0.01:
                self._update_user_requirements(carriage)
    
    def _update_user_requirements(self, user: Dict):
        """Update user's application requirements"""
        app_type = SimulationEngine.assign_application_type()
        app_data = SimulationEngine.APP_TYPES[app_type]
        
        data_size = app_data["data_size"] * random.uniform(0.5, 1.5)
        latency_req = app_data["latency_req"] * random.uniform(0.8, 1.2)
        
        user["app_type"] = app_type
        user["data_size"] = round(data_size, 2)
        user["latency_req"] = round(latency_req, 1)
        user["priority"] = app_data["priority"]
        
        if self.semcom_enabled_var.get():
            user["bw_req"] = self.engine.calculate_bandwidth_requirement_semcom(
                data_size, latency_req, self.semcom_compression_ratio.get()
            )
        else:
            user["bw_req"] = self.engine.calculate_bandwidth_requirement(data_size, latency_req)
    
    def _update_status_bar(self, metrics: Dict):
        """Update status bar with current metrics"""
        total_users = len(self.road_vehicles_list) + len(self.train_carriages_list)
        self.status_var.set(
            f"Running - Users: {total_users}, "
            f"Roads: {len(self.vehicle_paths)}, "
            f"{MetricsLogger.format_metrics_summary(metrics)}"
        )
    
    def redraw_canvas(self):
        """Redraw the entire canvas"""
        if self.renderer is None:
            return
        
        self.renderer.clear_canvas()
        
        # Draw roads
        self.renderer.draw_osm_roads(self.road_ways)
        
        # Draw train track
        if self.train_carriages_list:
            canvas_bounds = self.sim_canvas.cget("scrollregion").split()
            max_x = float(canvas_bounds[2]) if len(canvas_bounds) >= 3 else 1000
            self.renderer.draw_train_track(self.train_carriages_list, max_x)
        
        # Draw vehicles
        all_aps = self.bs_list + self.sat_list
        for vehicle in self.road_vehicles_list:
            self.renderer.draw_road_vehicle(vehicle, all_aps)
        
        for carriage in self.train_carriages_list:
            self.renderer.draw_train_carriage(carriage, all_aps)
        
        # Draw access points
        for bs in self.bs_list:
            self.renderer.draw_base_station(bs)
        
        for sat in self.sat_list:
            self.renderer.draw_satellite(sat)
        
        # Draw legend
        canvas_bounds = self.sim_canvas.cget("scrollregion").split()
        if len(canvas_bounds) >= 4:
            max_x = float(canvas_bounds[2])
            max_y = float(canvas_bounds[3])
        else:
            max_x, max_y = 1000, 700
        
        self.renderer.draw_legend(max_x, max_y)
    
    def center_map(self):
        """Center the map in the canvas view"""
        if not self.osm_nodes or self.renderer is None:
            return
        
        xs = [node.x for node in self.osm_nodes.values()]
        ys = [node.y for node in self.osm_nodes.values()]
        
        if not xs or not ys:
            return
        
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        
        canvas_width = self.sim_canvas.winfo_width()
        canvas_height = self.sim_canvas.winfo_height()
        
        if canvas_width <= 1 or canvas_height <= 1:
            return
        
        map_width = max_x - min_x
        map_height = max_y - min_y
        
        if map_width == 0 or map_height == 0:
            return
        
        margin = 50
        scale_x = (canvas_width - 2 * margin) / map_width
        scale_y = (canvas_height - 2 * margin) / map_height
        scale = min(scale_x, scale_y)
        
        center_x = (min_x + max_x) / 2
        center_y = (min_y + max_y) / 2
        canvas_center_x = canvas_width / 2
        canvas_center_y = canvas_height / 2
        
        # Set renderer scale and offset
        self.renderer.scale = scale
        self.renderer.offset_x = canvas_center_x - center_x * scale
        self.renderer.offset_y = canvas_center_y - center_y * scale
        
        # Redraw with new view
        self.redraw_canvas()
    
    def update_requirement_displays(self):
        """Update the requirement display tables"""
        # Clear existing items
        for tree in [self.vehicle_tree, self.train_tree, self.ap_tree]:
            for item in tree.get_children():
                tree.delete(item)
        
        # Update vehicle requirements
        for vehicle in self.road_vehicles_list:
            self.vehicle_tree.insert("", "end", values=(
                vehicle["id"], vehicle["app_type"], vehicle["data_size"],
                vehicle["latency_req"], vehicle["priority"], vehicle["bw_req"]
            ))
        
        # Update train requirements
        for carriage in self.train_carriages_list:
            self.train_tree.insert("", "end", values=(
                carriage["id"], carriage["app_type"], carriage["data_size"],
                carriage["latency_req"], carriage["priority"], carriage["bw_req"]
            ))
        
        # Update access point information
        for ap in self.bs_list + self.sat_list:
            utilization = ((ap["total_bw"] - ap["available_bw"]) / ap["total_bw"]) * 100 if ap["total_bw"] > 0 else 0
            self.ap_tree.insert("", "end", values=(
                ap["id"], ap["type"],
                f"{ap['available_bw']:.1f} / {ap['total_bw']:.1f}",
                len(ap["connected_users"]), f"{utilization:.1f}"
            ))


if __name__ == "__main__":
    app = EnhancedScenarioSimulator()
    app.mainloop()