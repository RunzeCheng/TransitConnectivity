"""
OSM file parsing and coordinate conversion utilities
"""
import xml.etree.ElementTree as ET
from typing import Dict, List, Tuple
import math
from models import OSMNode, OSMWay, VehiclePath


class OSMParser:
    """Handles parsing of OSM XML files and coordinate conversion"""
    
    ROAD_TYPES = [
        'motorway', 'trunk', 'primary', 'secondary', 'tertiary',
        'unclassified', 'residential', 'service', 'motorway_link',
        'trunk_link', 'primary_link', 'secondary_link', 'tertiary_link'
    ]
    
    @staticmethod
    def parse_osm_file(file_path: str) -> Tuple[Dict[str, OSMNode], Dict[str, OSMWay], List[OSMWay]]:
        """
        Parse OSM XML file
        
        Returns:
            Tuple of (nodes_dict, ways_dict, road_ways_list)
        """
        tree = ET.parse(file_path)
        root = tree.getroot()
        
        # Parse nodes
        nodes = {}
        for node_elem in root.findall('node'):
            node_id = node_elem.get('id')
            lat = float(node_elem.get('lat'))
            lon = float(node_elem.get('lon'))
            nodes[node_id] = OSMNode(node_id, lat, lon)
        
        # Parse ways
        ways = {}
        road_ways = []
        
        for way_elem in root.findall('way'):
            way_id = way_elem.get('id')
            
            # Get node references
            node_refs = [nd.get('ref') for nd in way_elem.findall('nd')]
            
            # Get tags
            tags = {}
            for tag in way_elem.findall('tag'):
                tags[tag.get('k')] = tag.get('v')
            
            # Check if this is a road
            is_road = 'highway' in tags and tags['highway'] in OSMParser.ROAD_TYPES
            
            way = OSMWay(way_id, node_refs, tags, is_road)
            ways[way_id] = way
            
            if is_road:
                road_ways.append(way)
        
        return nodes, ways, road_ways
    
    @staticmethod
    def get_bounds(nodes: Dict[str, OSMNode]) -> Tuple[float, float, float, float]:
        """Calculate min/max latitude and longitude from nodes"""
        if not nodes:
            return None, None, None, None
        
        lats = [node.lat for node in nodes.values()]
        lons = [node.lon for node in nodes.values()]
        
        return min(lats), max(lats), min(lons), max(lons)
    
    @staticmethod
    def convert_coordinates_to_canvas(
        nodes: Dict[str, OSMNode],
        min_lat: float,
        max_lat: float,
        min_lon: float,
        max_lon: float,
        canvas_width: int = 1800,
        canvas_height: int = 1200,
        margin: int = 50
    ) -> None:
        """Convert lat/lon coordinates to canvas coordinates in-place"""
        if not nodes or min_lat is None:
            return
        
        # Calculate scale
        lat_range = max_lat - min_lat
        lon_range = max_lon - min_lon
        
        if lat_range == 0 or lon_range == 0:
            return
        
        scale_x = (canvas_width - 2 * margin) / lon_range
        scale_y = (canvas_height - 2 * margin) / lat_range
        scale = min(scale_x, scale_y)  # Use same scale for both axes
        
        # Convert all nodes
        for node in nodes.values():
            node.x = margin + (node.lon - min_lon) * scale
            node.y = margin + (max_lat - node.lat) * scale  # Flip Y axis
    
    @staticmethod
    def create_vehicle_paths(
        road_ways: List[OSMWay],
        nodes: Dict[str, OSMNode]
    ) -> List[VehiclePath]:
        """Create vehicle paths from road ways"""
        vehicle_paths = []
        
        for way in road_ways:
            # Create polyline from nodes
            polyline = []
            for node_id in way.nodes:
                if node_id in nodes:
                    node = nodes[node_id]
                    polyline.append((node.x, node.y))
            
            if len(polyline) >= 2:
                way.polyline = polyline
                
                # Calculate total length
                length = 0
                for i in range(len(polyline) - 1):
                    dx = polyline[i+1][0] - polyline[i][0]
                    dy = polyline[i+1][1] - polyline[i][1]
                    length += math.sqrt(dx*dx + dy*dy)
                way.length = length
                
                # Create vehicle path
                path = VehiclePath(way, nodes)
                vehicle_paths.append(path)
        
        return vehicle_paths
    
    @staticmethod
    def create_sample_data() -> Tuple[Dict[str, OSMNode], Dict[str, OSMWay], List[OSMWay]]:
        """Create sample OSM data for testing"""
        # Create sample nodes for a small road network
        sample_nodes = [
            OSMNode("1", 52.5200, 13.4050, 0, 0),
            OSMNode("2", 52.5210, 13.4060, 0, 0),
            OSMNode("3", 52.5220, 13.4070, 0, 0),
            OSMNode("4", 52.5200, 13.4080, 0, 0),
            OSMNode("5", 52.5180, 13.4070, 0, 0),
            OSMNode("6", 52.5190, 13.4050, 0, 0),
            OSMNode("7", 52.5210, 13.4040, 0, 0),
            OSMNode("8", 52.5230, 13.4050, 0, 0),
        ]
        
        nodes = {node.id: node for node in sample_nodes}
        
        # Create sample ways (roads)
        sample_ways = [
            OSMWay("way1", ["1", "2", "3"], {"highway": "primary", "name": "Main Street"}, True),
            OSMWay("way2", ["4", "5", "6"], {"highway": "secondary", "name": "Second Street"}, True),
            OSMWay("way3", ["1", "6", "7"], {"highway": "residential", "name": "Side Street"}, True),
            OSMWay("way4", ["2", "8", "3"], {"highway": "tertiary", "name": "Cross Street"}, True),
            OSMWay("way5", ["5", "8"], {"highway": "residential", "name": "Short Street"}, True),
        ]
        
        ways = {way.id: way for way in sample_ways}
        road_ways = sample_ways
        
        return nodes, ways, road_ways