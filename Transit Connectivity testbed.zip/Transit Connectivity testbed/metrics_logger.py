"""
Metrics calculation and CSV logging utilities
"""
import csv
import os
from typing import Dict, Optional


class MetricsLogger:
    """Handles metrics calculation and CSV logging"""
    
    CSV_FIELDNAMES = [
        "tick",
        "throughput_mbps",
        "goodput_mbps",
        "total_used_mhz",
        "successful_bw_used_mhz",
        "success_ratio",
        "successful_users",
        "total_users",
        "total_original_data_mb",
        "dt_type",
        "dt_cloud_delay_ms",
        "semcom_enabled",
        "compression_ratio",
    ]
    
    def __init__(self, testnum: int = 0):
        self.testnum = testnum
    
    def set_testnum(self, testnum: int):
        """Set the test number for CSV filename"""
        self.testnum = testnum
    
    def get_filename(self) -> str:
        """Get the CSV filename for current test number"""
        return f"Result_{self.testnum}.csv"
    
    def log_metrics(
        self,
        tick: int,
        metrics: Dict[str, float],
        dt_type: str,
        dt_cloud_delay_ms: float,
        semcom_enabled: bool,
        compression_ratio: float
    ):
        """Append metrics to CSV file"""
        filename = self.get_filename()
        file_exists = os.path.isfile(filename)
        
        with open(filename, mode="a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self.CSV_FIELDNAMES)
            
            if not file_exists:
                writer.writeheader()
            
            writer.writerow({
                "tick": tick,
                "throughput_mbps": round(metrics["throughput_mbps"], 3),
                "goodput_mbps": round(metrics["goodput_mbps"], 3),
                "total_used_mhz": round(metrics["total_used_mhz"], 3),
                "successful_bw_used_mhz": round(metrics["successful_bw_used_mhz"], 3),
                "success_ratio": round(metrics["success_ratio"], 2),
                "successful_users": metrics["successful_users"],
                "total_users": metrics["total_users"],
                "total_original_data_mb": round(metrics["total_original_data_mb"], 3),
                "dt_type": dt_type,
                "dt_cloud_delay_ms": dt_cloud_delay_ms,
                "semcom_enabled": semcom_enabled,
                "compression_ratio": round(compression_ratio, 3),
            })
    
    def clear_csv(self) -> bool:
        """Clear the current CSV file and recreate with header"""
        filename = self.get_filename()
        
        try:
            if os.path.isfile(filename):
                os.remove(filename)
            
            # Recreate with header
            with open(filename, mode="w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=self.CSV_FIELDNAMES)
                writer.writeheader()
            
            return True
        except Exception as e:
            print(f"Error clearing CSV: {e}")
            return False
    
    @staticmethod
    def format_metrics_summary(metrics: Dict[str, float]) -> str:
        """Format metrics for display"""
        return (
            f"Throughput: {metrics['throughput_mbps']:.1f} Mbps | "
            f"Goodput: {metrics['goodput_mbps']:.1f} Mbps | "
            f"Success Rate: {metrics['success_ratio']:.1f}% "
            f"({metrics['successful_users']}/{metrics['total_users']})"
        )