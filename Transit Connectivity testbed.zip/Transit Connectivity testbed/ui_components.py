"""
UI components builder for the simulation application
"""
import tkinter as tk
from tkinter import ttk, messagebox
from visualization import CanvasRenderer


class UIBuilder:
    """Builds all UI components for the application"""
    
    def __init__(self, app):
        self.app = app
    
    def create_all_widgets(self):
        """Create all UI widgets"""
        # Main container
        main_container = ttk.Frame(self.app)
        main_container.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Horizontal split
        paned = ttk.Panedwindow(main_container, orient="horizontal")
        paned.pack(fill="both", expand=True)
        
        left_panel = ttk.Frame(paned)
        right_panel = ttk.Frame(paned)
        
        paned.add(left_panel, weight=0)
        paned.add(right_panel, weight=1)
        self.app.after(0, lambda: paned.sashpos(0, 360))
        
        # Left panel with vertical split
        self._create_left_panel(left_panel)
        
        # Right panel with canvas
        self._create_canvas_panel(right_panel)
        
        # Status bar
        self._create_status_bar()
    
    def _create_left_panel(self, parent):
        """Create left control panel"""
        left_vpaned = ttk.Panedwindow(parent, orient="vertical")
        left_vpaned.pack(fill="both", expand=True)
        
        controls_container = ttk.Frame(left_vpaned)
        req_container = ttk.Frame(left_vpaned)
        
        left_vpaned.add(controls_container, weight=0)
        left_vpaned.add(req_container, weight=1)
        self.app.after(0, lambda: left_vpaned.sashpos(0, 220))
        
        # Controls in tabs
        self._create_control_tabs(controls_container)
        
        # Requirements display
        self._create_requirements_panel(req_container)
    
    def _create_control_tabs(self, parent):
        """Create tabbed control interface"""
        notebook = ttk.Notebook(parent)
        notebook.pack(fill="both", expand=True)
        
        tab_osm = ttk.Frame(notebook)
        tab_sim = ttk.Frame(notebook)
        tab_results = ttk.Frame(notebook)
        tab_semcom = ttk.Frame(notebook)
        tab_map = ttk.Frame(notebook)
        
        notebook.add(tab_osm, text="OSM")
        notebook.add(tab_sim, text="Simulation")
        notebook.add(tab_results, text="Logging")
        notebook.add(tab_semcom, text="SemCom")
        notebook.add(tab_map, text="Map")
        
        self._create_osm_controls(tab_osm)
        self._create_simulation_controls(tab_sim)
        self._create_logging_controls(tab_results)
        self._create_semcom_controls(tab_semcom)
        self._create_map_controls(tab_map)
    
    def _create_osm_controls(self, parent):
        """Create OSM file loading controls"""
        frame = ttk.Frame(parent, padding=6)
        frame.pack(fill="x", pady=4)
        
        self.app.osm_status = tk.StringVar(value="No OSM file loaded")
        ttk.Label(frame, textvariable=self.app.osm_status, wraplength=200).pack(pady=2)
        
        ttk.Button(frame, text="Load OSM File", command=self.app.load_osm_file).pack(pady=5)
        ttk.Button(frame, text="Load Sample Data", command=self.app.load_sample_osm).pack(pady=2)
    
    def _create_simulation_controls(self, parent):
        """Create simulation parameter controls"""
        frame = ttk.Frame(parent, padding=6)
        frame.pack(fill="x", pady=4)
        
        # Road vehicles
        self._create_slider(frame, "Number of Road Vehicles:", 
                          self.app.road_vehicle_count, 0, 500,
                          self._update_road_label, "road_value_label")
        
        # Train carriages
        self._create_slider(frame, "Number of Train Carriages:",
                          self.app.train_carriages, 0, 10,
                          self._update_rail_label, "rail_value_label")
        
        # Base stations
        self._create_slider(frame, "Number of Base Station Cells:",
                          self.app.base_stations, 0, 50,
                          self._update_bs_label, "bs_value_label")
        
        # Satellites
        self._create_slider(frame, "Number of Satellites:",
                          self.app.satellites, 0, 6,
                          self._update_sat_label, "sat_value_label")
        
        # Control buttons
        button_frame = ttk.Frame(frame)
        button_frame.pack(pady=10)
        
        self.app.start_button = ttk.Button(button_frame, text="Start Simulation",
                                          command=self.app.simulate_scenario)
        self.app.start_button.pack(side="left", padx=2)
        
        self.app.stop_button = ttk.Button(button_frame, text="Stop Simulation",
                                         command=self.app.stop_simulation, state="disabled")
        self.app.stop_button.pack(side="left", padx=2)
    
    def _create_slider(self, parent, label_text, variable, from_, to, 
                      update_callback, label_attr):
        """Create a labeled slider control"""
        ttk.Label(parent, text=label_text).pack(pady=2)
        
        slider = ttk.Scale(parent, from_=from_, to=to, orient="horizontal",
                          variable=variable, command=update_callback)
        slider.pack(fill="x", padx=5)
        
        label = ttk.Label(parent, text=f"Current: {variable.get()}")
        label.pack(pady=2)
        setattr(self.app, label_attr, label)
    
    def _create_logging_controls(self, parent):
        """Create logging controls"""
        frame = ttk.Frame(parent, padding=6)
        frame.pack(fill="x", pady=4)
        
        ttk.Label(frame, text="Test Number (suffix for Result_<n>.csv)").pack(pady=2, anchor="w")
        
        testnum_var = tk.StringVar(value="0")
        entry = ttk.Entry(frame, textvariable=testnum_var, width=12)
        entry.pack(fill="x", padx=5)
        
        def on_testnum_change(event=None):
            try:
                value = int(testnum_var.get())
                if value < 0:
                    value = 0
                self.app.logger.set_testnum(value)
            except:
                testnum_var.set(str(self.app.logger.testnum))
        
        entry.bind("<FocusOut>", on_testnum_change)
        entry.bind("<Return>", on_testnum_change)
        
        def clear_csv():
            if self.app.logger.clear_csv():
                self.app.status_var.set(f"Cleared {self.app.logger.get_filename()}")
            else:
                messagebox.showerror("Error", "Failed to clear CSV file")
        
        ttk.Button(frame, text="Clear Current CSV", command=clear_csv).pack(pady=6)
    
    def _create_semcom_controls(self, parent):
        """Create SemCom configuration controls"""
        frame = ttk.Frame(parent, padding=6)
        frame.pack(fill="x", pady=4)
        
        # SemCom toggle
        def on_semcom_toggle():
            enabled = self.app.semcom_enabled_var.get()
            for user in self.app.road_vehicles_list + self.app.train_carriages_list:
                data_size = user.get("data_size", 0.0)
                latency_req = user.get("latency_req", 1000.0)
                if enabled and self.app.engine:
                    user["bw_req"] = self.app.engine.calculate_bandwidth_requirement_semcom(
                        data_size, latency_req, self.app.semcom_compression_ratio.get()
                    )
                elif self.app.engine:
                    user["bw_req"] = self.app.engine.calculate_bandwidth_requirement(
                        data_size, latency_req
                    )
            self.app.update_requirement_displays()
        
        ttk.Checkbutton(frame, text="Enable SemCom",
                       variable=self.app.semcom_enabled_var,
                       command=on_semcom_toggle).pack(anchor="w")
        
        # Compression ratio
        ttk.Label(frame, text="Compression Ratio (0.1 - 1.0)").pack(pady=2, anchor="w")
        
        def update_compression(event=None):
            if hasattr(self.app, "semcom_value_label"):
                self.app.semcom_value_label.config(
                    text=f"Current: {self.app.semcom_compression_ratio.get():.2f}"
                )
            if self.app.semcom_enabled_var.get() and self.app.engine:
                for user in self.app.road_vehicles_list + self.app.train_carriages_list:
                    data_size = user.get("data_size", 0.0)
                    latency_req = user.get("latency_req", 1000.0)
                    user["bw_req"] = self.app.engine.calculate_bandwidth_requirement_semcom(
                        data_size, latency_req, self.app.semcom_compression_ratio.get()
                    )
                self.app.update_requirement_displays()
        
        slider = ttk.Scale(frame, from_=0.1, to=1.0, orient="horizontal",
                          variable=self.app.semcom_compression_ratio,
                          command=update_compression)
        slider.pack(fill="x", padx=5)
        
        self.app.semcom_value_label = ttk.Label(
            frame,
            text=f"Current: {self.app.semcom_compression_ratio.get():.2f}"
        )
        self.app.semcom_value_label.pack(pady=2, anchor="w")
        
        # Digital Twin type
        ttk.Label(frame, text="Digital Twin Type:", 
                 font=("Arial", 9, "bold")).pack(pady=(10, 2), anchor="w")
        
        dt_frame = ttk.Frame(frame)
        dt_frame.pack(fill="x", pady=2)
        
        ttk.Radiobutton(dt_frame, text="Traditional DT",
                       variable=self.app.dt_type_var,
                       value="traditional").pack(side="left", padx=(0, 10))
        ttk.Radiobutton(dt_frame, text="Multilayer DT",
                       variable=self.app.dt_type_var,
                       value="multilayer").pack(side="left")
        
        ttk.Label(frame, text="Traditional DT: +50ms cloud delay",
                 font=("Arial", 8), foreground="gray").pack(anchor="w")
        ttk.Label(frame, text="Multilayer DT: No cloud delay",
                 font=("Arial", 8), foreground="gray").pack(anchor="w")
    
    def _create_map_controls(self, parent):
        """Create map view controls"""
        frame = ttk.Frame(parent, padding=6)
        frame.pack(fill="x", pady=4)
        
        ttk.Button(frame, text="Center Map", command=self.app.center_map).pack(pady=2)
        ttk.Button(frame, text="Reset Zoom", 
                  command=lambda: (self.app.renderer.reset_zoom() if self.app.renderer else None,
                                 self.app.redraw_canvas() if hasattr(self.app, 'redraw_canvas') else None)).pack(pady=2)
        ttk.Label(frame, text="Use mouse wheel to zoom", 
                 font=("Arial", 8), foreground="gray").pack(pady=2)
    
    def _create_requirements_panel(self, parent):
        """Create requirements display panel"""
        frame = ttk.LabelFrame(parent, text="User Requirements", padding=6)
        frame.pack(fill="both", expand=True, pady=4)
        
        notebook = ttk.Notebook(frame)
        notebook.pack(fill="both", expand=True)
        
        # Vehicle requirements
        vehicle_frame = ttk.Frame(notebook)
        notebook.add(vehicle_frame, text="Vehicle Users")
        self._create_requirements_tree(vehicle_frame, "vehicle_tree")
        
        # Train requirements
        train_frame = ttk.Frame(notebook)
        notebook.add(train_frame, text="Train Users")
        self._create_requirements_tree(train_frame, "train_tree")
        
        # Access points
        ap_frame = ttk.Frame(notebook)
        notebook.add(ap_frame, text="Access Points")
        self._create_ap_tree(ap_frame)
    
    def _create_requirements_tree(self, parent, attr_name):
        """Create a treeview for user requirements"""
        ttk.Label(parent, text="User Requirements:", 
                 font=("Arial", 10, "bold")).pack(pady=5)
        
        columns = ("ID", "App Type", "Data (MB)", "Latency (ms)", "Priority", "BW Req (MHz)")
        tree = ttk.Treeview(parent, columns=columns, show="headings", height=6)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=70 if col == "ID" else 80)
        
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        setattr(self.app, attr_name, tree)
    
    def _create_ap_tree(self, parent):
        """Create treeview for access points"""
        ttk.Label(parent, text="Access Point Capacities:",
                 font=("Arial", 10, "bold")).pack(pady=5)
        
        columns = ("ID", "Type", "Available BW (MHz)", "Connected Users", "Utilization (%)")
        tree = ttk.Treeview(parent, columns=columns, show="headings", height=6)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=100)
        
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        self.app.ap_tree = tree
    
    def _create_canvas_panel(self, parent):
        """Create the simulation canvas panel"""
        canvas_frame = ttk.LabelFrame(parent, text="Simulation Visualization", padding=5)
        canvas_frame.pack(fill="both", expand=True)
        
        canvas_container = ttk.Frame(canvas_frame)
        canvas_container.pack(fill="both", expand=True)
        
        self.app.sim_canvas = tk.Canvas(canvas_container, width=1000, height=700,
                                       bg="white", scrollregion=(0, 0, 2000, 2000))
        
        # Scrollbars
        h_scrollbar = ttk.Scrollbar(canvas_container, orient="horizontal",
                                   command=self.app.sim_canvas.xview)
        v_scrollbar = ttk.Scrollbar(canvas_container, orient="vertical",
                                   command=self.app.sim_canvas.yview)
        
        self.app.sim_canvas.configure(xscrollcommand=h_scrollbar.set,
                                     yscrollcommand=v_scrollbar.set)
        
        self.app.sim_canvas.pack(side="left", fill="both", expand=True)
        v_scrollbar.pack(side="right", fill="y")
        h_scrollbar.pack(side="bottom", fill="x")
        
        # Pan bindings
        self.app.sim_canvas.bind("<ButtonPress-1>", self.app.start_pan)
        self.app.sim_canvas.bind("<B1-Motion>", self.app.pan_move)
        self.app.sim_canvas.bind("<ButtonRelease-1>", self.app.end_pan)
        
        # Mouse wheel zoom bindings
        # Windows and Mac
        self.app.sim_canvas.bind("<MouseWheel>", self.app.on_mousewheel)
        # Linux
        self.app.sim_canvas.bind("<Button-4>", self.app.on_mousewheel)
        self.app.sim_canvas.bind("<Button-5>", self.app.on_mousewheel)
        
        # Make canvas focusable to receive mouse wheel events
        self.app.sim_canvas.focus_set()
        self.app.sim_canvas.bind("<Enter>", lambda e: self.app.sim_canvas.focus_set())
        self.app.sim_canvas.bind("<Leave>", lambda e: self.app.sim_canvas.focus_set())

        # Initialize renderer
        self.app.renderer = CanvasRenderer(self.app.sim_canvas)
    
    def _create_status_bar(self):
        """Create status bar"""
        self.app.status_var = tk.StringVar(value="Ready to simulate - Load an OSM file first")
        status_bar = ttk.Label(self.app, textvariable=self.app.status_var, relief="sunken")
        status_bar.pack(side="bottom", fill="x")
    
    # Update label callbacks
    def _update_road_label(self, event):
        self.app.road_value_label.config(
            text=f"Current: {int(self.app.road_vehicle_count.get())}"
        )
    
    def _update_rail_label(self, event):
        self.app.rail_value_label.config(
            text=f"Current: {int(self.app.train_carriages.get())}"
        )
    
    def _update_bs_label(self, event):
        self.app.bs_value_label.config(
            text=f"Current: {int(self.app.base_stations.get())}"
        )
    
    def _update_sat_label(self, event):
        self.app.sat_value_label.config(
            text=f"Current: {int(self.app.satellites.get())}"
        )