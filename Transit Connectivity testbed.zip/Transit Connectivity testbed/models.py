"""
Data models for the OSM Connectivity Simulator
"""
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
import math


@dataclass
class OSMNode:
    """Represents a node in OpenStreetMap data"""
    id: str
    lat: float
    lon: float
    x: float = 0.0  # Canvas coordinates
    y: float = 0.0


@dataclass
class OSMWay:
    """Represents a way (road) in OpenStreetMap data"""
    id: str
    nodes: List[str]  # Node IDs
    tags: Dict[str, str]
    is_road: bool = False
    polyline: List[Tuple[float, float]] = None  # Canvas coordinates
    length: float = 0.0  # Total length in pixels


class VehiclePath:
    """Represents a path that a vehicle follows"""
    
    def __init__(self, way: OSMWay, nodes: Dict[str, OSMNode]):
        self.way = way
        self.nodes = nodes
        self.polyline = way.polyline
        self.length = way.length
        self.current_segment = 0
        self.segment_progress = 0.0
        
    def get_position_at_progress(self, progress: float) -> Tuple[float, float]:
        """Get x, y position at given progress (0.0 to 1.0) along the path"""
        if not self.polyline or len(self.polyline) < 2:
            return (400, 300)  # Default position
        
        if progress <= 0:
            return self.polyline[0]
        if progress >= 1:
            return self.polyline[-1]
        
        # Find which segment we're on
        target_distance = progress * self.length
        current_distance = 0
        
        for i in range(len(self.polyline) - 1):
            start = self.polyline[i]
            end = self.polyline[i + 1]
            segment_length = math.sqrt((end[0] - start[0])**2 + (end[1] - start[1])**2)
            
            if current_distance + segment_length >= target_distance:
                # We're in this segment
                segment_progress = (target_distance - current_distance) / segment_length
                x = start[0] + (end[0] - start[0]) * segment_progress
                y = start[1] + (end[1] - start[1]) * segment_progress
                return (x, y)
            
            current_distance += segment_length
        
        return self.polyline[-1]  # Fallback to end
    
    def get_direction_at_progress(self, progress: float) -> float:
        """Get direction angle at given progress"""
        if not self.polyline or len(self.polyline) < 2:
            return 0
        
        # Get two close points to calculate direction
        pos1 = self.get_position_at_progress(max(0, progress - 0.01))
        pos2 = self.get_position_at_progress(min(1, progress + 0.01))
        
        dx = pos2[0] - pos1[0]
        dy = pos2[1] - pos1[1]
        
        return math.atan2(dy, dx)