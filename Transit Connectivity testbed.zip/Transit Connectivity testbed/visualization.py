"""
Visualization utilities for the simulation canvas
"""
import tkinter as tk
import math
from typing import List, Dict
from models import OSMWay


class CanvasRenderer:
    """Handles all canvas drawing operations"""
    
    # Road visualization configuration
    ROAD_COLORS = {
        'motorway': '#e892a2',
        'trunk': '#f9b29c',
        'primary': '#fcd6a4',
        'secondary': '#f7fabf',
        'tertiary': '#c8facc',
        'unclassified': '#ddd',
        'residential': '#eee',
        'service': '#ccc'
    }
    
    ROAD_WIDTHS = {
        'motorway': 8,
        'trunk': 6,
        'primary': 5,
        'secondary': 4,
        'tertiary': 3,
        'unclassified': 3,
        'residential': 2,
        'service': 2
    }
    
    def __init__(self, canvas: tk.Canvas):
        self.canvas = canvas

        # Zoom/Pan state
        self.scale = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.min_scale = 0.1
        self.max_scale = 5.0
        
        # Fixed font sizes (don't scale with zoom)
        self.ROAD_LABEL_FONT_SIZE = 10
        self.LEGEND_FONT_SIZE_TITLE = 10
        self.LEGEND_FONT_SIZE_SUB = 9
        self.LEGEND_FONT_SIZE_TEXT = 8
    
    def clear_canvas(self):
        """Clear all items from canvas"""
        self.canvas.delete("all")
        
    def sx(self, x): 
        """Transform x coordinate with scale and offset"""
        return x * self.scale + self.offset_x
    def sy(self, y): 
        """Transform y coordinate with scale and offset"""
        return y * self.scale + self.offset_y
    
    def zoom_at_point(self, x, y, factor):
        """Zoom in/out at a specific point (mouse position)"""
        # Calculate the point in world coordinates before zoom
        world_x = (x - self.offset_x) / self.scale
        world_y = (y - self.offset_y) / self.scale
        
        # Update scale
        new_scale = self.scale * factor
        new_scale = max(self.min_scale, min(self.max_scale, new_scale))
        
        # Calculate new offset to keep the same point under the mouse
        self.offset_x = x - world_x * new_scale
        self.offset_y = y - world_y * new_scale
        self.scale = new_scale
    
    def zoom_in(self, x, y):
        """Zoom in at point (x, y)"""
        self.zoom_at_point(x, y, 1.2)
    
    def zoom_out(self, x, y):
        """Zoom out at point (x, y)"""
        self.zoom_at_point(x, y, 1.0 / 1.2)
    
    def reset_zoom(self):
        """Reset zoom and pan to default"""
        self.scale = 1.0
        self.offset_x = 0
        self.offset_y = 0
    
    def get_road_width_multiplier(self):
        """Calculate road width multiplier based on visible map area.
        Larger visible areas (zoomed out) use thinner roads to prevent clutter.
        Smaller visible areas (zoomed in) use thicker roads for better visibility.
        """
        try:
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            
            if canvas_width <= 1 or canvas_height <= 1 or self.scale <= 0:
                return 1.0
            
            # Calculate visible world area
            # Visible world width = canvas width / scale
            # Visible world height = canvas height / scale
            visible_world_area = (canvas_width * canvas_height) / (self.scale * self.scale)
            
            # Reference area for scale 1.0 (baseline)
            # Assuming typical canvas size of 1000x700
            reference_area = 1000 * 700
            
            # Calculate multiplier: larger area = smaller multiplier (thinner roads)
            # Use square root to make the scaling more gradual
            area_ratio = visible_world_area / reference_area
            multiplier = 1.0 / (1.0 + 0.5 * math.sqrt(area_ratio))
            
            # Clamp multiplier to reasonable bounds
            multiplier = max(0.3, min(2.0, multiplier))
            
            return multiplier
        except:
            return 1.0

    def draw_osm_roads(self, road_ways: List[OSMWay]):
        """Draw OSM road network"""
        if not road_ways:
            return
        
        for way in road_ways:
            if not way.polyline or len(way.polyline) < 2:
                continue
            
            highway_type = way.tags.get('highway', 'unclassified')
            color = self.ROAD_COLORS.get(highway_type, '#ddd')
            width = self.ROAD_WIDTHS.get(highway_type, 2)
            
            # Calculate adaptive road width based on visible area
            width_multiplier = self.get_road_width_multiplier()
            adaptive_width = width * width_multiplier
            
            # Draw road as connected line segments
            for i in range(len(way.polyline) - 1):
                x1, y1 = way.polyline[i]
                x2, y2 = way.polyline[i + 1]
                # Apply scale and offset transformations
                sx1, sy1 = self.sx(x1), self.sy(y1)
                sx2, sy2 = self.sx(x2), self.sy(y2)
                # Use adaptive width (minimum 0.5 pixels for visibility)
                scaled_width = max(0.5, adaptive_width)
                self.canvas.create_line(sx1, sy1, sx2, sy2, 
                                      fill=color, width=scaled_width, tags="roads")
            
            # Draw road name at midpoint with fixed font size
            if 'name' in way.tags and len(way.polyline) > 2:
                mid_idx = len(way.polyline) // 2
                mid_x, mid_y = way.polyline[mid_idx]
                smx, smy = self.sx(mid_x), self.sy(mid_y)
                # Fixed font size - doesn't scale with zoom
                self.canvas.create_text(smx, smy, text=way.tags['name'], 
                                      fill="darkblue", font=("Arial", self.ROAD_LABEL_FONT_SIZE, "bold"), 
                                      tags="road_names")
    
    def draw_train_track(self, carriages: List[Dict], max_x: float):
        """Draw train track"""
        if not carriages:
            return
        
        track_y = 100
        sx1, sy1 = self.sx(50), self.sy(track_y)
        sx2, sy2 = self.sx(max_x - 50), self.sy(track_y)
        # Use adaptive width for train track
        width_multiplier = self.get_road_width_multiplier()
        scaled_width = max(0.5, 4 * width_multiplier)
        self.canvas.create_line(sx1, sy1, sx2, sy2, 
                              fill="brown", width=scaled_width, tags="infrastructure")
        stx, sty = self.sx(max_x // 2), self.sy(track_y - 20)
        # Fixed font size for labels
        self.canvas.create_text(stx, sty, text="Train Track", 
                              fill="brown", font=("Arial", self.ROAD_LABEL_FONT_SIZE, "bold"), tags="labels")
    
    def draw_road_vehicle(self, vehicle: Dict, access_points: List[Dict]):
        """Draw a road vehicle with direction arrow and connection"""
        x, y = vehicle["x"], vehicle["y"]
        direction = vehicle.get("direction", 0)
        
        # Transform coordinates
        sx, sy = self.sx(x), self.sy(y)
        
        # Draw connection line to access point
        if vehicle["connected_to"]:
            for ap in access_points:
                if ap["id"] == vehicle["connected_to"]:
                    apx, apy = self.sx(ap["x"]), self.sy(ap["y"])
                    # Connection lines scale with zoom for visibility
                    scaled_width = max(0.5, 2 * self.scale)
                    self.canvas.create_line(sx, sy, apx, apy, 
                                          fill="blue", width=scaled_width, dash=(3, 3), 
                                          tags="connections")
                    break
        
        # Draw vehicle as arrow showing direction
        color = self._get_priority_color(vehicle["priority"])
        
        # Scale arrow size with zoom for visibility
        arrow_length = 20 * self.scale
        arrow_width = 12 * self.scale
        
        # Arrow tip
        tip_x = sx + arrow_length * math.cos(direction)
        tip_y = sy + arrow_length * math.sin(direction)
        
        # Arrow base corners
        base_angle1 = direction + 2.5
        base_angle2 = direction - 2.5
        base_x1 = sx + arrow_width * math.cos(base_angle1)
        base_y1 = sy + arrow_width * math.sin(base_angle1)
        base_x2 = sx + arrow_width * math.cos(base_angle2)
        base_y2 = sy + arrow_width * math.sin(base_angle2)
        
        # Draw arrow
        points = [tip_x, tip_y, base_x1, base_y1, base_x2, base_y2]
        self.canvas.create_polygon(points, fill=color, outline="black", tags="vehicles")
        
        # Draw vehicle ID with fixed font size
        label_offset = 25 * self.scale  # Position scales, but font size doesn't
        self.canvas.create_text(sx, sy - label_offset, text=vehicle["id"], 
                              fill="black", font=("Arial", self.ROAD_LABEL_FONT_SIZE, "bold"), tags="labels")
    
    def draw_train_carriage(self, carriage: Dict, access_points: List[Dict]):
        """Draw a train carriage with connection"""
        x, y = carriage["x"], carriage["y"]
        
        # Transform coordinates
        sx, sy = self.sx(x), self.sy(y)
        
        # Draw connection line
        if carriage["connected_to"]:
            for ap in access_points:
                if ap["id"] == carriage["connected_to"]:
                    apx, apy = self.sx(ap["x"]), self.sy(ap["y"])
                    # Connection lines scale with zoom for visibility
                    scaled_width = max(0.5, 2 * self.scale)
                    self.canvas.create_line(sx, sy, apx, apy, 
                                          fill="green", width=scaled_width, dash=(3, 3), 
                                          tags="connections")
                    break
        
        # Draw carriage (scale size with zoom for visibility)
        size = 20 * self.scale
        color = self._get_priority_color(carriage["priority"])
        outline_width = max(0.5, 2 * self.scale)
        self.canvas.create_rectangle(sx - size, sy - size/2, sx + size, sy + size/2, 
                                   fill=color, outline="black", width=outline_width, tags="vehicles")
        # Fixed font size for labels
        label_offset = size + 5 * self.scale
        self.canvas.create_text(sx, sy - label_offset, text=carriage["id"], 
                              fill="black", font=("Arial", self.ROAD_LABEL_FONT_SIZE, "bold"), tags="labels")
    
    def draw_base_station(self, bs: Dict):
        """Draw a base station tower"""
        x, y = bs["x"], bs["y"]
        utilization = ((bs["total_bw"] - bs["available_bw"]) / bs["total_bw"]) * 100 if bs["total_bw"] > 0 else 0
        color = self._get_utilization_color(utilization)
        
        # Transform coordinates
        sx, sy = self.sx(x), self.sy(y)
        
        # Draw tower (scale size with zoom for visibility)
        tower_size = 20 * self.scale
        points = [sx, sy - tower_size, sx - tower_size*0.6, sy + tower_size*0.6, 
                 sx + tower_size*0.6, sy + tower_size*0.6]
        outline_width = max(0.5, 2 * self.scale)
        self.canvas.create_polygon(points, fill=color, outline="black", width=outline_width, 
                                 tags="infrastructure")
        # Fixed font size for labels
        label_offset = tower_size + 10 * self.scale
        self.canvas.create_text(sx, sy + label_offset, text=f"{bs['id']}\n{utilization:.0f}%", 
                              fill="black", font=("Arial", self.ROAD_LABEL_FONT_SIZE, "bold"), tags="labels")
    
    def draw_satellite(self, sat: Dict):
        """Draw a satellite with solar panels"""
        x, y = sat["x"], sat["y"]
        utilization = ((sat["total_bw"] - sat["available_bw"]) / sat["total_bw"]) * 100 if sat["total_bw"] > 0 else 0
        color = self._get_utilization_color(utilization)
        
        # Transform coordinates
        sx, sy = self.sx(x), self.sy(y)
        
        # Draw satellite body (scale size with zoom for visibility)
        sat_size = 15 * self.scale
        outline_width = max(0.5, 2 * self.scale)
        self.canvas.create_oval(sx - sat_size, sy - sat_size, sx + sat_size, sy + sat_size, 
                              fill=color, outline="black", width=outline_width, tags="infrastructure")
        
        # Draw solar panels
        panel_size = sat_size * 0.8
        panel_width = max(0.5, 1 * self.scale)
        self.canvas.create_rectangle(sx - sat_size - panel_size, sy - sat_size*0.2, 
                                   sx - sat_size, sy + sat_size*0.2, 
                                   fill="blue", outline="black", width=panel_width, 
                                   tags="infrastructure")
        self.canvas.create_rectangle(sx + sat_size, sy - sat_size*0.2, 
                                   sx + sat_size + panel_size, sy + sat_size*0.2, 
                                   fill="blue", outline="black", width=panel_width, 
                                   tags="infrastructure")
        
        # Fixed font size for labels
        label_offset = sat_size + 15 * self.scale
        self.canvas.create_text(sx, sy + label_offset, text=f"{sat['id']}\n{utilization:.0f}%", 
                              fill="black", font=("Arial", self.ROAD_LABEL_FONT_SIZE, "bold"), tags="labels")
    
    def draw_legend(self, max_x: float, max_y: float):
        """Draw legend for the visualization"""
        # Transform legend position (position scales with zoom, but sizes are fixed)
        legend_x = self.sx(max_x - 250)
        legend_y = self.sy(max_y - 200)
        
        # Fixed legend size (doesn't scale with zoom for readability)
        legend_width = 240
        legend_height = 180
        padding = 10
        spacing = 15
        
        # Legend background
        self.canvas.create_rectangle(legend_x - padding, legend_y - padding, 
                                   legend_x + legend_width, legend_y + legend_height, 
                                   fill="white", outline="black", tags="legend")
        
        self.canvas.create_text(legend_x, legend_y, text="Legend:", 
                              fill="black", font=("Arial", self.LEGEND_FONT_SIZE_TITLE, "bold"), 
                              anchor="w", tags="legend")
        
        # Priority legend
        self.canvas.create_text(legend_x, legend_y + 20, text="Priority:", 
                              fill="black", font=("Arial", self.LEGEND_FONT_SIZE_SUB, "bold"), 
                              anchor="w", tags="legend")
        
        priorities = [("High (3)", "red"), ("Medium (2)", "orange"), ("Low (1)", "lightblue")]
        for i, (label, color) in enumerate(priorities):
            y_pos = legend_y + 35 + i * spacing
            oval_size = 10
            self.canvas.create_oval(legend_x, y_pos, legend_x + oval_size, y_pos + oval_size, 
                                  fill=color, outline="black", tags="legend")
            self.canvas.create_text(legend_x + 15, y_pos + 5, text=label, 
                                  fill="black", font=("Arial", self.LEGEND_FONT_SIZE_TEXT), anchor="w", tags="legend")
        
        # Utilization legend
        self.canvas.create_text(legend_x + 120, legend_y + 20, text="AP Utilization:", 
                              fill="black", font=("Arial", self.LEGEND_FONT_SIZE_SUB, "bold"), 
                              anchor="w", tags="legend")
        
        utilizations = [("<40%", "lightgreen"), ("40-60%", "yellow"), 
                       ("60-80%", "orange"), (">80%", "red")]
        for i, (label, color) in enumerate(utilizations):
            y_pos = legend_y + 35 + i * spacing
            rect_size = 10
            self.canvas.create_rectangle(legend_x + 120, y_pos, 
                                       legend_x + 120 + rect_size, y_pos + rect_size, 
                                       fill=color, outline="black", tags="legend")
            self.canvas.create_text(legend_x + 135, y_pos + 5, text=label, 
                                  fill="black", font=("Arial", self.LEGEND_FONT_SIZE_TEXT), anchor="w", tags="legend")
        
        # Road types legend
        self.canvas.create_text(legend_x, legend_y + 100, text="Road Types:", 
                              fill="black", font=("Arial", self.LEGEND_FONT_SIZE_SUB, "bold"), 
                              anchor="w", tags="legend")
        
        road_types = [("Motorway", "#e892a2", 6), ("Primary", "#fcd6a4", 4), 
                     ("Secondary", "#f7fabf", 3), ("Residential", "#eee", 1)]
        for i, (label, color, width) in enumerate(road_types):
            y_pos = legend_y + 115 + i * spacing
            # Use fixed width for legend road samples
            self.canvas.create_line(legend_x, y_pos + 5, 
                                  legend_x + 20, y_pos + 5, 
                                  fill=color, width=width, tags="legend")
            self.canvas.create_text(legend_x + 25, y_pos + 5, text=label, 
                                  fill="black", font=("Arial", self.LEGEND_FONT_SIZE_TEXT), anchor="w", tags="legend")
    
    @staticmethod
    def _get_priority_color(priority: int) -> str:
        """Return color based on priority level"""
        if priority >= 3:
            return "red"
        elif priority >= 2:
            return "orange"
        else:
            return "lightblue"
    
    @staticmethod
    def _get_utilization_color(utilization: float) -> str:
        """Return color based on utilization percentage"""
        if utilization >= 80:
            return "red"
        elif utilization >= 60:
            return "orange"
        elif utilization >= 40:
            return "yellow"
        else:
            return "lightgreen"