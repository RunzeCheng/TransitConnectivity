"""
Bridges the core simulation logic with the Django views.
"""
from __future__ import annotations

import json
import random
from typing import Dict, List

from django.utils import timezone

from .logic.metrics_logger import MetricsLogger
from .logic.osm_parser import OSMParser
from .logic.simulation_logic import SimulationEngine


class SimulationManager:
    """Stateful helper that prepares a snapshot for the web front-end."""

    def __init__(self):
        self.semcom_config = {
            "bandwidth_mb_s": 12.5,
            "base_delay_s": 0.001,
            "compute_capacity_mb_s": 1000000 / 16,
            "alpha": 1.0,
        }
        self.dt_config = {"type": "traditional", "cloud_delay_ms": 50.0}

        self.road_vehicle_count = 35
        self.train_carriages = 2
        self.base_stations = 5
        self.satellites = 1
        self.vehicle_speed = 0.01

        self.semcom_enabled = True
        self.semcom_compression_ratio = 0.45

        self.osm_nodes = {}
        self.osm_ways = {}
        self.road_ways: List = []
        self.vehicle_paths: List = []
        self.map_loaded = False

        self.road_vehicles_list: List[Dict] = []
        self.train_carriages_list: List[Dict] = []
        self.bs_list: List[Dict] = []
        self.sat_list: List[Dict] = []

        self.tick = 0
        self.engine = SimulationEngine(self.semcom_config, self.dt_config)
        self.logger = MetricsLogger(testnum=0)

    # ------------------------------------------------------------------
    # Data preparation helpers
    # ------------------------------------------------------------------
    def ensure_map_data(self) -> None:
        if self.map_loaded:
            return

        self.osm_nodes, self.osm_ways, self.road_ways = OSMParser.create_sample_data()
        min_lat, max_lat, min_lon, max_lon = OSMParser.get_bounds(self.osm_nodes)
        OSMParser.convert_coordinates_to_canvas(self.osm_nodes, min_lat, max_lat, min_lon, max_lon)
        self.vehicle_paths = OSMParser.create_vehicle_paths(self.road_ways, self.osm_nodes)
        self.map_loaded = True

    def initialize_simulation_objects(self) -> None:
        self.ensure_map_data()

        self.road_vehicles_list = []
        self.train_carriages_list = []
        self.bs_list = []
        self.sat_list = []

        for i in range(self.road_vehicle_count):
            if not self.vehicle_paths:
                break
            path = random.choice(self.vehicle_paths)
            progress = random.uniform(0, 1)
            vehicle = self.engine.create_road_vehicle(
                f"V{i+1}",
                path,
                progress,
                self.semcom_enabled,
                self.semcom_compression_ratio,
            )
            self.road_vehicles_list.append(vehicle)

        canvas_width = 1000
        track_y = 120
        spacing = canvas_width // (self.train_carriages + 1) if self.train_carriages else 0
        for i in range(self.train_carriages):
            carriage = self.engine.create_train_carriage(
                f"C{i+1}",
                spacing * (i + 1),
                track_y,
                self.semcom_enabled,
                self.semcom_compression_ratio,
            )
            self.train_carriages_list.append(carriage)

        self._create_access_points(self.base_stations, self.satellites)

    def _create_access_points(self, bs_count: int, sat_count: int) -> None:
        if self.osm_nodes:
            xs = [node.x for node in self.osm_nodes.values()]
            ys = [node.y for node in self.osm_nodes.values()]
            min_x, max_x = min(xs), max(xs)
            min_y, max_y = min(ys), max(ys)
        else:
            min_x, max_x = 100, 900
            min_y, max_y = 100, 600

        for i in range(bs_count):
            self.bs_list.append(
                {
                    "id": f"BS{i+1}",
                    "type": "Base Station",
                    "x": random.uniform(min_x + 50, max_x - 50),
                    "y": random.uniform(min_y + 50, max_y - 50),
                    "total_bw": 20,
                    "available_bw": 20,
                    "connected_users": [],
                }
            )

        center_x = (min_x + max_x) / 2 if max_x > min_x else 500
        for i in range(sat_count):
            self.sat_list.append(
                {
                    "id": f"SAT{i+1}",
                    "type": "Satellite",
                    "x": center_x + (i * 50 - (sat_count - 1) * 25),
                    "y": min_y - 80,
                    "total_bw": 500,
                    "available_bw": 500,
                    "connected_users": [],
                }
            )

    # ------------------------------------------------------------------
    # Simulation updates
    # ------------------------------------------------------------------
    def _update_vehicles(self) -> None:
        for vehicle in self.road_vehicles_list:
            vehicle["progress"] += self.vehicle_speed

            if vehicle["progress"] >= 1.0:
                vehicle["progress"] = 0.0
                if random.random() < 0.1 and self.vehicle_paths:
                    vehicle["path"] = random.choice(self.vehicle_paths)

            vehicle["x"], vehicle["y"] = vehicle["path"].get_position_at_progress(vehicle["progress"])
            vehicle["direction"] = vehicle["path"].get_direction_at_progress(vehicle["progress"])

            if random.random() < 0.02:
                self._update_user_requirements(vehicle)

        for carriage in self.train_carriages_list:
            carriage["x"] = carriage["x"] + random.randint(-2, 2)
            if random.random() < 0.01:
                self._update_user_requirements(carriage)

    def _update_user_requirements(self, user: Dict) -> None:
        app_type = SimulationEngine.assign_application_type()
        app_data = SimulationEngine.APP_TYPES[app_type]

        data_size = app_data["data_size"] * random.uniform(0.5, 1.5)
        latency_req = app_data["latency_req"] * random.uniform(0.8, 1.2)

        user["app_type"] = app_type
        user["data_size"] = round(data_size, 2)
        user["latency_req"] = round(latency_req, 1)
        user["priority"] = app_data["priority"]

        if self.semcom_enabled:
            user["bw_req"] = self.engine.calculate_bandwidth_requirement_semcom(
                data_size, latency_req, self.semcom_compression_ratio
            )
        else:
            user["bw_req"] = self.engine.calculate_bandwidth_requirement(data_size, latency_req)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def generate_snapshot(self, tick_steps: int = 3) -> Dict:
        if not self.map_loaded:
            self.ensure_map_data()
        if not self.road_vehicles_list:
            self.initialize_simulation_objects()

        metrics = {}
        for _ in range(tick_steps):
            self._update_vehicles()
            all_users = self.road_vehicles_list + self.train_carriages_list
            all_aps = self.bs_list + self.sat_list
            SimulationEngine.assign_connections(all_users, all_aps)
            metrics = SimulationEngine.calculate_metrics(all_users, all_aps)
            self.tick += 1

        snapshot = {
            "generated_at": timezone.now().isoformat(),
            "tick": self.tick,
            "semcom_enabled": self.semcom_enabled,
            "compression_ratio": self.semcom_compression_ratio,
            "dt_type": self.dt_config["type"],
            "metrics": metrics,
            "roads": [
                {
                    "id": way.id,
                    "polyline": way.polyline,
                    "highway": way.tags.get("highway", "residential"),
                    "name": way.tags.get("name", way.id),
                }
                for way in self.road_ways
                if way.polyline
            ],
            "vehicles": [
                {
                    "id": item["id"],
                    "x": item["x"],
                    "y": item["y"],
                    "priority": item["priority"],
                    "app_type": item["app_type"],
                    "bw_req": item["bw_req"],
                    "connected_to": item["connected_to"],
                    "type": "road",
                }
                for item in self.road_vehicles_list
            ]
            + [
                {
                    "id": carriage["id"],
                    "x": carriage["x"],
                    "y": carriage["y"],
                    "priority": carriage["priority"],
                    "app_type": carriage["app_type"],
                    "bw_req": carriage["bw_req"],
                    "connected_to": carriage["connected_to"],
                    "type": "train",
                }
                for carriage in self.train_carriages_list
            ],
            "access_points": self.bs_list + self.sat_list,
        }
        return snapshot

    @staticmethod
    def to_json(snapshot: Dict) -> str:
        return json.dumps(snapshot)

