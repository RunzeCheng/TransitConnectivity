from django.urls import path
from . import views

app_name = "simulator"

urlpatterns = [
    path("", views.index, name="index"),
    path("snapshot/", views.snapshot_api, name="snapshot-api"),
]


