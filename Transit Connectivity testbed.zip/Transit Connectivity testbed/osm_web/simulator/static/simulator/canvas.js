(() => {
  const canvas = document.getElementById("sim-canvas");
  const ctx = canvas.getContext("2d");
  const refreshBtn = document.getElementById("refresh-btn");
  const statusLabel = document.getElementById("status-label");

  const metricEls = {
    throughput: document.getElementById("metric-throughput"),
    goodput: document.getElementById("metric-goodput"),
    success: document.getElementById("metric-success"),
    users: document.getElementById("metric-users"),
  };

  const cfgEls = {
    semcom: document.getElementById("cfg-semcom"),
    compression: document.getElementById("cfg-compression"),
    dt: document.getElementById("cfg-dt"),
    tick: document.getElementById("cfg-tick"),
  };

  const lists = {
    vehicles: document.getElementById("vehicle-list"),
    aps: document.getElementById("ap-list"),
  };

  const colors = {
    roads: {
      motorway: "#e892a2",
      trunk: "#f9b29c",
      primary: "#fcd6a4",
      secondary: "#f7fabf",
      tertiary: "#c8facc",
      residential: "#eeeeee",
      service: "#cccccc",
      default: "#dddddd",
    },
    priority: {
      1: "#87cefa",
      2: "#ffb347",
      3: "#ff5252",
    },
    ap: {
      "Base Station": "#4CAF50",
      Satellite: "#673AB7",
    },
  };

  function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  function drawRoads(roads) {
    ctx.lineCap = "round";
    roads.forEach((road) => {
      if (!road.polyline || road.polyline.length < 2) return;
      ctx.beginPath();
      const color = colors.roads[road.highway] || colors.roads.default;
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1, 6 - roads.length / 40);
      road.polyline.forEach(([x, y], index) => {
        if (index === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    });
  }

  function drawVehicles(vehicles) {
    vehicles.forEach((vehicle) => {
      ctx.beginPath();
      const color = colors.priority[vehicle.priority] || colors.priority[1];
      ctx.fillStyle = color;
      ctx.strokeStyle = "#111";
      const size = vehicle.type === "train" ? 10 : 6;
      ctx.arc(vehicle.x, vehicle.y, size, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    });
  }

  function drawAccessPoints(accessPoints) {
    accessPoints.forEach((ap) => {
      ctx.beginPath();
      ctx.fillStyle = colors.ap[ap.type] || "#ffffff";
      ctx.strokeStyle = "#111";
      ctx.rect(ap.x - 8, ap.y - 8, 16, 16);
      ctx.fill();
      ctx.stroke();
    });
  }

  function updateMetrics(snapshot) {
    const metrics = snapshot.metrics || {};
    metricEls.throughput.textContent = (metrics.throughput_mbps || 0).toFixed(1);
    metricEls.goodput.textContent = (metrics.goodput_mbps || 0).toFixed(1);
    metricEls.success.textContent = (metrics.success_ratio || 0).toFixed(1);
    metricEls.users.textContent = metrics.total_users || 0;

    cfgEls.semcom.textContent = snapshot.semcom_enabled ? "Enabled" : "Disabled";
    cfgEls.compression.textContent = snapshot.compression_ratio.toFixed(2);
    cfgEls.dt.textContent = snapshot.dt_type;
    cfgEls.tick.textContent = snapshot.tick;
  }

  function populateLists(snapshot) {
    lists.vehicles.innerHTML = "";
    snapshot.vehicles.slice(0, 8).forEach((vehicle) => {
      const li = document.createElement("li");
      li.textContent = `${vehicle.id}: ${vehicle.app_type} (${vehicle.bw_req.toFixed(2)} MHz)`;
      lists.vehicles.appendChild(li);
    });

    lists.aps.innerHTML = "";
    snapshot.access_points.forEach((ap) => {
      const utilization =
        ((ap.total_bw - ap.available_bw) / ap.total_bw) * 100 || 0;
      const li = document.createElement("li");
      li.textContent = `${ap.id} (${ap.type}) — ${utilization.toFixed(1)}% utilised`;
      lists.aps.appendChild(li);
    });
  }

  function renderSnapshot(snapshot) {
    clearCanvas();
    drawRoads(snapshot.roads || []);
    drawAccessPoints(snapshot.access_points || []);
    drawVehicles(snapshot.vehicles || []);
    updateMetrics(snapshot);
    populateLists(snapshot);
  }

  async function requestSnapshot() {
    try {
      refreshBtn.disabled = true;
      statusLabel.textContent = "Refreshing…";
      const response = await fetch("/snapshot/");
      if (!response.ok) throw new Error("Request failed");
      const data = await response.json();
      window.simulationSnapshot = data;
      renderSnapshot(data);
      statusLabel.textContent = "Live";
    } catch (err) {
      console.error(err);
      statusLabel.textContent = "Error";
    } finally {
      refreshBtn.disabled = false;
    }
  }

  refreshBtn?.addEventListener("click", requestSnapshot);

  if (window.simulationSnapshot) {
    renderSnapshot(window.simulationSnapshot);
  }
})();


