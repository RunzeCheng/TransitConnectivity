"""
Placeholder pointing to the desktop UI builder implementation.
"""
from pathlib import Path

REFERENCE_IMPLEMENTATION = Path(__file__).resolve().parents[3] / "ui_components.py"


