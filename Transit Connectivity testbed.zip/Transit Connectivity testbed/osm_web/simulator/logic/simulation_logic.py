"""
Core simulation logic shared between the desktop and web demos.
"""
from __future__ import annotations

import math
import random
from typing import Dict, List

from .models import VehiclePath


class SimulationEngine:
    """Handles the core simulation logic and calculations."""

    APP_TYPES = {
        "File Transfer": {"data_size": 50.0, "latency_req": 10000, "priority": 1},
        "IoT Sensing": {"data_size": 0.01, "latency_req": 500, "priority": 1},
        "Charging Scheduling": {"data_size": 0.5, "latency_req": 1000, "priority": 1},
        "Voice Call": {"data_size": 0.1, "latency_req": 150, "priority": 2},
        "Traffic Planning": {"data_size": 0.5, "latency_req": 150, "priority": 2},
        "Autonomous Driving": {"data_size": 1.0, "latency_req": 50, "priority": 3},
    }

    def __init__(self, semcom_config: Dict, dt_config: Dict):
        self.semcom_config = semcom_config
        self.dt_config = dt_config

    @staticmethod
    def assign_application_type() -> str:
        return random.choice(list(SimulationEngine.APP_TYPES.keys()))

    def calculate_bandwidth_requirement(self, data_size_mb: float, latency_req_ms: float) -> float:
        if self.dt_config.get("type") == "traditional":
            latency_req_ms = max(1, latency_req_ms - self.dt_config.get("cloud_delay_ms", 50.0))

        data_bits = data_size_mb * 8 * 1024 * 1024
        latency_sec = max(1e-6, latency_req_ms / 1000.0)
        required_bw_bps = (data_bits / latency_sec) * 1.5
        required_bw_mhz = required_bw_bps / 1000000 / 6
        return round(required_bw_mhz, 3)

    def calculate_bandwidth_requirement_semcom(
        self, data_size_mb: float, latency_req_ms: float, compression_ratio: float
    ) -> float:
        if self.dt_config.get("type") == "traditional":
            latency_req_ms = max(1, latency_req_ms - self.dt_config.get("cloud_delay_ms", 50.0))

        compression_ratio = max(1e-6, min(1.0, compression_ratio))
        base_delay_s = max(0.0, float(self.semcom_config.get("base_delay_s", 0.001)))

        alpha = float(self.semcom_config.get("alpha", 1.0))
        compute_capacity_mb_s = max(1e-6, float(self.semcom_config.get("compute_capacity_mb_s", 62500)))
        compute_load_mb = data_size_mb / (compression_ratio ** alpha)
        compute_delay_s = compute_load_mb / compute_capacity_mb_s

        latency_s = max(1e-6, float(latency_req_ms) / 1000.0)
        tx_time_budget_s = latency_s - base_delay_s - compute_delay_s
        compressed_size_mb = data_size_mb * compression_ratio

        if tx_time_budget_s <= 1e-6:
            return float("inf")

        required_throughput_mb_s = compressed_size_mb / tx_time_budget_s
        required_bw_bps = required_throughput_mb_s * 8 * 1024 * 1024
        required_bw_mhz = required_bw_bps / 1000000.0 / 6.0
        return round(required_bw_mhz, 3)

    def create_road_vehicle(
        self,
        vehicle_id: str,
        path: VehiclePath,
        progress: float,
        semcom_enabled: bool,
        compression_ratio: float,
    ) -> Dict:
        app_type = self.assign_application_type()
        app_data = self.APP_TYPES[app_type]

        data_size = app_data["data_size"] * random.uniform(0.5, 1.5)
        latency_req = app_data["latency_req"] * random.uniform(0.8, 1.2)

        if semcom_enabled:
            bw_requirement = self.calculate_bandwidth_requirement_semcom(
                data_size, latency_req, compression_ratio
            )
        else:
            bw_requirement = self.calculate_bandwidth_requirement(data_size, latency_req)

        x, y = path.get_position_at_progress(progress)
        direction = path.get_direction_at_progress(progress)

        return {
            "id": vehicle_id,
            "path": path,
            "progress": progress,
            "direction": direction,
            "x": x,
            "y": y,
            "app_type": app_type,
            "data_size": round(data_size, 2),
            "latency_req": round(latency_req, 1),
            "priority": app_data["priority"],
            "bw_req": bw_requirement,
            "connected_to": None,
            "access_success": False,
        }

    def create_train_carriage(
        self,
        carriage_id: str,
        x: float,
        y: float,
        semcom_enabled: bool,
        compression_ratio: float,
    ) -> Dict:
        app_type = self.assign_application_type()
        app_data = self.APP_TYPES[app_type]

        data_size = app_data["data_size"] * random.uniform(0.5, 1.5)
        latency_req = app_data["latency_req"] * random.uniform(0.8, 1.2)

        if semcom_enabled:
            bw_requirement = self.calculate_bandwidth_requirement_semcom(
                data_size, latency_req, compression_ratio
            )
        else:
            bw_requirement = self.calculate_bandwidth_requirement(data_size, latency_req)

        return {
            "id": carriage_id,
            "x": x,
            "y": y,
            "app_type": app_type,
            "data_size": round(data_size, 2),
            "latency_req": round(latency_req, 1),
            "priority": app_data["priority"],
            "bw_req": bw_requirement,
            "connected_to": None,
            "access_success": False,
        }

    @staticmethod
    def assign_connections(users: List[Dict], access_points: List[Dict]) -> None:
        for ap in access_points:
            ap["connected_users"] = []
            ap["available_bw"] = ap["total_bw"]

        for user in users:
            user["connected_to"] = None
            user["access_success"] = False

        sorted_users = sorted(users, key=lambda x: x["priority"], reverse=True)

        for user in sorted_users:
            best_ap = None
            min_distance = float("inf")
            had_sufficient_capacity = False

            for ap in access_points:
                distance = math.dist((user["x"], user["y"]), (ap["x"], ap["y"]))

                if distance < min_distance and ap["available_bw"] >= user["bw_req"]:
                    min_distance = distance
                    best_ap = ap
                    had_sufficient_capacity = True

            if best_ap is None:
                for ap in access_points:
                    distance = math.dist((user["x"], user["y"]), (ap["x"], ap["y"]))
                    if distance < min_distance:
                        min_distance = distance
                        best_ap = ap

            if best_ap:
                user["connected_to"] = best_ap["id"]
                best_ap["connected_users"].append(user["id"])
                user["access_success"] = had_sufficient_capacity
                best_ap["available_bw"] = max(0, best_ap["available_bw"] - user["bw_req"])

    @staticmethod
    def calculate_metrics(users: List[Dict], access_points: List[Dict]) -> Dict[str, float]:
        total_used_mhz = sum((ap["total_bw"] - ap["available_bw"]) for ap in access_points)
        raw_throughput_mbps = total_used_mhz * 6.0

        successful_users = [u for u in users if u.get("access_success")]

        successful_bw_used_mhz = 0
        for ap in access_points:
            for user_id in ap["connected_users"]:
                user = next((u for u in users if u["id"] == user_id), None)
                if user and user.get("access_success"):
                    successful_bw_used_mhz += user.get("bw_req", 0)

        goodput_mbps = successful_bw_used_mhz * 6.0
        total_original_data_mb = sum(u.get("data_size", 0.0) for u in successful_users)

        total_users = len(users)
        success_ratio = (len(successful_users) / total_users * 100.0) if total_users else 0.0

        return {
            "throughput_mbps": raw_throughput_mbps,
            "goodput_mbps": goodput_mbps,
            "total_used_mhz": total_used_mhz,
            "successful_bw_used_mhz": successful_bw_used_mhz,
            "success_ratio": success_ratio,
            "successful_users": len(successful_users),
            "total_users": total_users,
            "total_original_data_mb": total_original_data_mb,
        }


