"""
Reference copy of the Tkinter visualization utilities from the desktop app.
This module is not imported by the Django views but is kept for parity.
"""
# The original desktop implementation lives at project root `visualization.py`.
# Keeping this file prevents import errors for tools that expect the module.
from pathlib import Path

REFERENCE_IMPLEMENTATION = Path(__file__).resolve().parents[3] / "visualization.py"


