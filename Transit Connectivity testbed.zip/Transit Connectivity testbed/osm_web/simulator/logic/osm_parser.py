"""
OSM parsing utilities reused by the web simulator.
"""
from __future__ import annotations

import math
import xml.etree.ElementTree as ET
from typing import Dict, List, Tuple

from .models import OSMNode, OSMWay, VehiclePath


class OSMParser:
    """Handles parsing of OSM XML files and coordinate conversion."""

    ROAD_TYPES = [
        "motorway",
        "trunk",
        "primary",
        "secondary",
        "tertiary",
        "unclassified",
        "residential",
        "service",
        "motorway_link",
        "trunk_link",
        "primary_link",
        "secondary_link",
        "tertiary_link",
    ]

    @staticmethod
    def parse_osm_file(
        file_path: str,
    ) -> Tuple[Dict[str, OSMNode], Dict[str, OSMWay], List[OSMWay]]:
        tree = ET.parse(file_path)
        root = tree.getroot()

        nodes: Dict[str, OSMNode] = {}
        for node_elem in root.findall("node"):
            node_id = node_elem.get("id")
            if not node_id:
                continue
            lat = float(node_elem.get("lat", 0))
            lon = float(node_elem.get("lon", 0))
            nodes[node_id] = OSMNode(node_id, lat, lon)

        ways: Dict[str, OSMWay] = {}
        road_ways: List[OSMWay] = []

        for way_elem in root.findall("way"):
            way_id = way_elem.get("id")
            if not way_id:
                continue

            node_refs = [nd.get("ref") for nd in way_elem.findall("nd") if nd.get("ref")]

            tags = {tag.get("k"): tag.get("v") for tag in way_elem.findall("tag")}
            highway = tags.get("highway")
            is_road = highway in OSMParser.ROAD_TYPES if highway else False

            way = OSMWay(way_id, node_refs, tags, is_road)
            ways[way_id] = way

            if is_road:
                road_ways.append(way)

        return nodes, ways, road_ways

    @staticmethod
    def get_bounds(nodes: Dict[str, OSMNode]) -> Tuple[float, float, float, float]:
        if not nodes:
            return 0, 0, 0, 0

        lats = [node.lat for node in nodes.values()]
        lons = [node.lon for node in nodes.values()]
        return min(lats), max(lats), min(lons), max(lons)

    @staticmethod
    def convert_coordinates_to_canvas(
        nodes: Dict[str, OSMNode],
        min_lat: float,
        max_lat: float,
        min_lon: float,
        max_lon: float,
        canvas_width: int = 1800,
        canvas_height: int = 1200,
        margin: int = 50,
    ) -> None:
        if not nodes or min_lat == max_lat or min_lon == max_lon:
            return

        lat_range = max_lat - min_lat
        lon_range = max_lon - min_lon

        scale_x = (canvas_width - 2 * margin) / lon_range
        scale_y = (canvas_height - 2 * margin) / lat_range
        scale = min(scale_x, scale_y)

        for node in nodes.values():
            node.x = margin + (node.lon - min_lon) * scale
            node.y = margin + (max_lat - node.lat) * scale

    @staticmethod
    def create_vehicle_paths(
        road_ways: List[OSMWay],
        nodes: Dict[str, OSMNode],
    ) -> List[VehiclePath]:
        paths: List[VehiclePath] = []
        for way in road_ways:
            polyline = []
            for node_id in way.nodes:
                node = nodes.get(node_id)
                if node:
                    polyline.append((node.x, node.y))

            if len(polyline) < 2:
                continue

            way.polyline = polyline

            length = 0.0
            for i in range(len(polyline) - 1):
                length += math.dist(polyline[i], polyline[i + 1])
            way.length = length

            paths.append(VehiclePath(way, nodes))
        return paths

    @staticmethod
    def create_sample_data() -> Tuple[Dict[str, OSMNode], Dict[str, OSMWay], List[OSMWay]]:
        sample_nodes = [
            OSMNode("1", 52.5200, 13.4050, 0, 0),
            OSMNode("2", 52.5210, 13.4060, 0, 0),
            OSMNode("3", 52.5220, 13.4070, 0, 0),
            OSMNode("4", 52.5200, 13.4080, 0, 0),
            OSMNode("5", 52.5180, 13.4070, 0, 0),
            OSMNode("6", 52.5190, 13.4050, 0, 0),
            OSMNode("7", 52.5210, 13.4040, 0, 0),
            OSMNode("8", 52.5230, 13.4050, 0, 0),
        ]

        nodes = {node.id: node for node in sample_nodes}
        sample_ways = [
            OSMWay("way1", ["1", "2", "3"], {"highway": "primary", "name": "Main Street"}, True),
            OSMWay("way2", ["4", "5", "6"], {"highway": "secondary", "name": "Second Street"}, True),
            OSMWay("way3", ["1", "6", "7"], {"highway": "residential", "name": "Side Street"}, True),
            OSMWay("way4", ["2", "8", "3"], {"highway": "tertiary", "name": "Cross Street"}, True),
            OSMWay("way5", ["5", "8"], {"highway": "residential", "name": "Short Street"}, True),
        ]
        ways = {way.id: way for way in sample_ways}
        return nodes, ways, sample_ways


