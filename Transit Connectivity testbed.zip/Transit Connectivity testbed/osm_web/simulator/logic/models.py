"""
Data models reused by the web-based simulator.
"""
from dataclasses import dataclass
from typing import List, Dict, Tuple
import math


@dataclass
class OSMNode:
    """Represents a node in OpenStreetMap data."""
    id: str
    lat: float
    lon: float
    x: float = 0.0  # Canvas coordinates
    y: float = 0.0


@dataclass
class OSMWay:
    """Represents a way (road) in OpenStreetMap data."""
    id: str
    nodes: List[str]
    tags: Dict[str, str]
    is_road: bool = False
    polyline: List[Tuple[float, float]] | None = None
    length: float = 0.0


class VehiclePath:
    """Represents a path that a vehicle follows."""

    def __init__(self, way: OSMWay, nodes: Dict[str, OSMNode]):
        self.way = way
        self.nodes = nodes
        self.polyline = way.polyline or []
        self.length = way.length

    def get_position_at_progress(self, progress: float) -> Tuple[float, float]:
        """Get x, y position at given progress (0.0 to 1.0) along the path."""
        if not self.polyline or len(self.polyline) < 2:
            return 400.0, 300.0

        if progress <= 0:
            return self.polyline[0]
        if progress >= 1:
            return self.polyline[-1]

        target_distance = progress * self.length
        current_distance = 0.0

        for i in range(len(self.polyline) - 1):
            start = self.polyline[i]
            end = self.polyline[i + 1]
            segment_length = math.dist(start, end)

            if current_distance + segment_length >= target_distance:
                segment_progress = (target_distance - current_distance) / segment_length
                x = start[0] + (end[0] - start[0]) * segment_progress
                y = start[1] + (end[1] - start[1]) * segment_progress
                return x, y

            current_distance += segment_length

        return self.polyline[-1]

    def get_direction_at_progress(self, progress: float) -> float:
        """Get direction angle at given progress."""
        if not self.polyline or len(self.polyline) < 2:
            return 0.0

        pos1 = self.get_position_at_progress(max(0, progress - 0.01))
        pos2 = self.get_position_at_progress(min(1, progress + 0.01))

        dx = pos2[0] - pos1[0]
        dy = pos2[1] - pos1[1]

        return math.atan2(dy, dx)


