from __future__ import annotations

import json

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET

from .simulation_manager import SimulationManager

manager = SimulationManager()


@require_GET
def index(request):
    """Render the landing page with an initial snapshot embedded."""
    snapshot = manager.generate_snapshot()
    context = {"snapshot_json": json.dumps(snapshot)}
    return render(request, "simulator/index.html", context)


@require_GET
def snapshot_api(request):
    """Return a fresh snapshot (used for AJAX refresh)."""
    snapshot = manager.generate_snapshot()
    return JsonResponse(snapshot, safe=False)


