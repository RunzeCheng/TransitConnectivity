"""Admin registrations for simulator models (none yet)."""


