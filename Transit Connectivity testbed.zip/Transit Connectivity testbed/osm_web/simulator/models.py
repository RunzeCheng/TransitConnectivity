"""Django models for simulator (not used in this demo)."""


