"""Django migrations package for simulator app."""


