from django.test import SimpleTestCase
from django.urls import reverse


class SimulatorViewTests(SimpleTestCase):
    def test_index_renders(self):
        response = self.client.get(reverse("simulator:index"))
        self.assertEqual(response.status_code, 200)
        self.assertIn("simulationSnapshot" , response.content.decode())


