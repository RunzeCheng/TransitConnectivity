"""Simulator Django app."""


