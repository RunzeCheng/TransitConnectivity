"""OSM web project package."""


