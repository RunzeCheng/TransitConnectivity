import traci
import random

traci.start(["sumo-gui", "-c", "yourmap.sumocfg"])

vehicle_count = random.randint(100, 150)
print("Generating", vehicle_count, "vehicles")

for i in range(vehicle_count):
    veh_id = f"veh{i}"
    traci.vehicle.add(veh_id, routeID="route0")
    traci.vehicle.setSpeed(veh_id, 10)   # optional

    traci.simulationStep()

traci.close()